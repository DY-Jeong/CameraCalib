

size_t frame_num=0;
    if(sscanf(file_name.c_str(),"%lu.png",&frame_num)==1){
        frame_nums[cam_num].insert(frame_num);
        all_frames.insert(frame_num);
    }